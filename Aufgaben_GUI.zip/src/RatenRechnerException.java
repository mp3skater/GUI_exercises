public class RatenRechnerException extends Exception {
    public RatenRechnerException(String message) {
        super(message);
    }
}
