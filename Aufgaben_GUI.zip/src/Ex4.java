import javax.swing.*;
import java.awt.*;

public class Ex4 extends JFrame {
    private JButton okButton;
    private JTextField inputField;

    public Ex4() {
        // Create a JTextField and JButton
        inputField = new JTextField(20);
        okButton = new JButton("OK");

        // Make okButton the default button
        this.getRootPane().setDefaultButton(okButton);

        // Action listener for OK button
        okButton.addActionListener(
                e -> JOptionPane.showMessageDialog(null, "OK button pressed via Enter key")
        );

        // Layout setup
        setLayout(new FlowLayout());
        add(inputField);
        add(okButton);

        // Frame settings
        setTitle("Default Button Example");
        setSize(300, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Ex4();
    }
}
